<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cosplay extends Model
{
    protected $fillable = [
        'kostum_karakter',
        'ukuran',
        'harga',
    ];

    //
}
